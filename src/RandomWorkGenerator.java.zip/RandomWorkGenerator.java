// Random Number Generator | Jenna Tran | Jan 25, 2024

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    System.out.println("Welcome to Random Word Generator!");

    // Create a collection of 20 prefixes
    List<String> prefixes = new ArrayList<>();
    prefixes.add("anti");
    prefixes.add("super");
    prefixes.add("mis");
    prefixes.add("non");
    prefixes.add("pre");
    prefixes.add("sub");
    prefixes.add("under");
    prefixes.add("inter");
    prefixes.add("intra");
    prefixes.add("ex");
    prefixes.add("re");
    prefixes.add("semi");
    prefixes.add("dis");
    prefixes.add("en");
    prefixes.add("post");
    prefixes.add("pre");
    prefixes.add("trans");
    prefixes.add("un");
    prefixes.add("over");
    prefixes.add("co");

    // Create a collection of 20 suffixes
    List<String> suffixes = new ArrayList<>();
    suffixes.add("ed");
    suffixes.add("or");
    suffixes.add("ful");
    suffixes.add("less");
    suffixes.add("ing");
    suffixes.add("est");
    suffixes.add("ment");
    suffixes.add("able");
    suffixes.add("ly");
    suffixes.add("ness");
    suffixes.add("er");
    suffixes.add("hood");
    suffixes.add("en");
    suffixes.add("ty");
    suffixes.add("s");
    suffixes.add("ous");
    suffixes.add("ive");
    suffixes.add("tion");
    suffixes.add("ship");
    suffixes.add("y");

    // Create a collection of 20 roots
    List<String> roots = new ArrayList<>();
    roots.add("aqua");
    roots.add("form");
    roots.add("mal");
    roots.add("jud");
    roots.add("mort");
    roots.add("cent");
    roots.add("dem");
    roots.add("dict");
    roots.add("cron");
    roots.add("phil");
    roots.add("phon");
    roots.add("nym");
    roots.add("fort");
    roots.add("fract");
    roots.add("sect");
    roots.add("voc");
    roots.add("port");
    roots.add("circum");
    roots.add("mater");
    roots.add("pater");

    // Add definitions to prefixxes
    List<String> preDef = new ArrayList<>();
    preDef.add("being against");
    preDef.add("going beyond");
    preDef.add("being not");
    preDef.add("being opposite of");
    preDef.add("before having");
    preDef.add("being under");
    preDef.add("being a little");
    preDef.add("being between");
    preDef.add("being within");
    preDef.add("being out of");
    preDef.add("again");
    preDef.add("partly being");
    preDef.add("not being");
    preDef.add("causing");
    preDef.add("after");
    preDef.add("before");
    preDef.add("being across");
    preDef.add("being the opposite of");
    preDef.add("too much");
    preDef.add("together being");

    // Add definitions to suffixes
    List<String> suffDef = new ArrayList<>();
    suffDef.add("In the past");
    suffDef.add("A person");
    suffDef.add("Fully");
    suffDef.add("Without");
    suffDef.add("Currently");
    suffDef.add("To the highest degree of");
    suffDef.add("A state of");
    suffDef.add("Capable of");
    suffDef.add("How something is");
    suffDef.add("State of");
    suffDef.add("An increased amount of");
    suffDef.add("Nature of");
    suffDef.add("Made of");
    suffDef.add("State of");
    suffDef.add("Multiple");
    suffDef.add("Having qualities of");
    suffDef.add("Tendency of");
    suffDef.add("Process or act of");
    suffDef.add("State or condition of");
    suffDef.add("Characterized by");

    // Add definitions to roots
    List<String> rootDef = new ArrayList<>();
    rootDef.add("water");
    rootDef.add("a shape");
    rootDef.add("bad");
    rootDef.add("judging");
    rootDef.add("death");
    rootDef.add("one hundred");
    rootDef.add("people");
    rootDef.add("speaking");
    rootDef.add("time");
    rootDef.add("loving");
    rootDef.add("sound");
    rootDef.add("naming");
    rootDef.add("strong");
    rootDef.add("broken");
    rootDef.add("cut");
    rootDef.add("voicing");
    rootDef.add("carry");
    rootDef.add("around");
    rootDef.add("mother");
    rootDef.add("father");

    // Print word and definition in one string concatenation

    Scanner scan = new Scanner(System.in);

    while (true) {
      // Create random number for each collection
      int prefixIndex = (int) (Math.random() * prefixes.size());
      int rootIndex = (int) (Math.random() * roots.size());
      int suffixIndex = (int) (Math.random() * suffixes.size());

      // Build the new word in a string concatenation using the random numbers
      String newWord = prefixes.get(prefixIndex) + roots.get(rootIndex) + suffixes.get(suffixIndex);
      System.out.println("Your word is: " + newWord);
      System.out.println(
          "Definition: " + suffDef.get(suffixIndex) + " " + preDef.get(prefixIndex) + " " + rootDef.get(rootIndex));

      // Ask to generate new word
      System.out.println("Would you like to generate another word? Y/N");
      String answer = scan.nextLine();

      // Breaks or continues word generator loop
      if (answer.equals("Y") || answer.equals("y")) {
        continue;
      } else if (answer.equals("N") || answer.equals("n")) {
        System.out.println("Thank you for using Random Word Generator!");
        break;
      }
    }
    scan.close();
  }
}